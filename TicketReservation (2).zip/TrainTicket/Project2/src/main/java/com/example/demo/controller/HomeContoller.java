package com.example.demo.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.example.demo.model.Train;

import com.example.demo.services.TrainService;


public class HomeContoller
{

@Autowired
private TrainService services;
@Autowired

@GetMapping("/")
public String Homepage()
{
	return "HomePage";
}

@GetMapping("/index")
public String viewHomePage(Model model) {
    List<Train> listtrain = services.listAll();
    model.addAttribute("listtrain", listtrain);
    System.out.print("Get /");
    return "index";
}

@GetMapping("/new")
public String addi(Model models) {
    models.addAttribute("train", new Train());
    return "new";
}

@RequestMapping(value = "/save", method = RequestMethod.POST)
public String saveTrain(@ModelAttribute("train") Train train) {
    services.save(train);
    return "redirect:/index";
}

@RequestMapping("/edit/{Train_no}")
public ModelAndView showEditTrainPage(@PathVariable(name = "Train_no") int id) {
    ModelAndView mav = new ModelAndView("new");
    Optional<Train> std = services.getTrainByNumber(id);
    mav.addObject("train", std);
    return mav;
    
}
@RequestMapping("/delete/{Train_no}")
public String deletetrain(@PathVariable(name = "Train_no") int id) {
    services.delete(id);
    return "redirect:/index";
}
}


