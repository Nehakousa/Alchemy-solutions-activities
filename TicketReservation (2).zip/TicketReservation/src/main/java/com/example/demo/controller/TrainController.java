package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.example.demo.domain.Train;
import com.example.demo.service.TrainServices;

@CrossOrigin(origins="*")
@Controller


public class TrainController {
	
	@Autowired
    private TrainServices service;
 
    @GetMapping("/")
    public String viewHomePage(Model model) {
        List<Train> listtrain = service.listAll();
        model.addAttribute("listtrain", listtrain);
        System.out.print("Get /");
        return "index";
    }
 
    @GetMapping("/new")
    public String add(Model model) {
        model.addAttribute("train", new Train());
        return "new";
    }
 
    @RequestMapping(value = "/save", method = RequestMethod.POST)
    public String saveTrain(@ModelAttribute("train") Train train) {
        service.save(train);
        return "redirect:/";
    }
 
    @RequestMapping("/edit/{Train_no}")
    public ModelAndView showEditTrainPage(@PathVariable(name = "Train_no") int id) {
        ModelAndView mav = new ModelAndView("new");
        Train std = service.get(id);
        mav.addObject("train", std);
        return mav;
        
    }
    @RequestMapping("/delete/{Train_no}")
    public String deletetrain(@PathVariable(name = "Train_no") int id) {
        service.delete(id);
        return "redirect:/";
    }
}


