package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.domain.Train;
import com.example.demo.domain.TrainTicket;
import com.example.demo.repository.TrainRepository;
import com.example.demo.repository.TrainTicketRepository;
@Service
public class TrainTicketService {
	@Autowired
    private TrainTicketRepository repo;
public List<TrainTicket> listAll() {
        return repo.findAll();
    }
    
    public void save(TrainTicket traint) {
        repo.save(traint);
    }
    
    public TrainTicket get(int Ticket_no) {
        return repo.findById(Ticket_no).get();
    }
    
    public void delete(int  Ticket_no) {
    	 repo.deleteById(Ticket_no);
    	
    }
    
   
}
