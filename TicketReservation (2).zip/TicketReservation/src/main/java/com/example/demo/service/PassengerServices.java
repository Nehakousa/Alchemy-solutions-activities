package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.domain.Passenger;
import com.example.demo.repository.PassengerRepository;

@Service
public class PassengerServices {
	@Autowired
    private PassengerRepository repo;
public List<Passenger> listAll() {
        return repo.findAll();
    }
    
    public void save(Passenger passenger) {
        repo.save(passenger);
    }
    
    public Passenger get(int pid) {
        return repo.findById(pid).get();
    }
    
    public void delete(int  pid) {
    	 repo.deleteById(pid);
    	
    }


}
