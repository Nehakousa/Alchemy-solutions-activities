package com.example.demo.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="users")
public class Signup {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int uid;
	
	@Column(name="username")
	private  String username;
	
	
	
	@Column(name="emailid")
	private String emailid;
	
	@Column(name="password")
	private String password;

	public Signup(String username,  String emailid, String password) {
		super();
		
		this.username = username;
		this.emailid = emailid;
		this.password = password;
	}

	public Signup() {
		
		// TODO Auto-generated constructor stub
	}

	public int getUid() {
		return uid;
	}

	public void setUid(int uid) {
		this.uid = uid;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	

	public String getEmailid() {
		return emailid;
	}

	public void setEmailid(String emailid) {
		this.emailid = emailid;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return "User [uid=" + uid + ", user_name=" +username+ ", email_id=" + emailid + ", password=" + password
				+ "]";
	}
	
	

}
