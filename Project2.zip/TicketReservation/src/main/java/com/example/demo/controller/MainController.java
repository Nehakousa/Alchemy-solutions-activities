package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.example.demo.domain.Passenger;
import com.example.demo.domain.Ticket;
import com.example.demo.domain.Train;
import com.example.demo.domain.TrainTicket;
import com.example.demo.service.PassengerServices;
import com.example.demo.service.TrainServices;
import com.example.demo.service.TrainTicketService;


@CrossOrigin(origins="*")
@Controller
public class MainController {
	
	@Autowired
    private TrainServices services;
	@Autowired
    private PassengerServices service;
	@Autowired
	private TrainTicketService servic;
	@GetMapping("/")
	public String Homepage()
	{
		return "HomePage";
	}
	
 @GetMapping("/index")
    public String viewHomePage(Model model) {
        List<Train> listtrain = services.listAll();
        model.addAttribute("listtrain", listtrain);
        System.out.print("Get /");
        return "index";
    }
 
    @GetMapping("/new")
    public String addi(Model models) {
        models.addAttribute("train", new Train());
        return "new";
    }
 
    @RequestMapping(value = "/save", method = RequestMethod.POST)
    public String saveTrain(@ModelAttribute("train") Train train) {
        services.save(train);
        return "redirect:/index";
    }
 
    @RequestMapping("/edit/{Train_no}")
    public ModelAndView showEditTrainPage(@PathVariable(name = "Train_no") int id) {
        ModelAndView mav = new ModelAndView("new");
        Train std = services.get(id);
        mav.addObject("train", std);
        return mav;
        
    }
    @RequestMapping("/delete/{Train_no}")
    public String deletetrain(@PathVariable(name = "Train_no") int id) {
        services.delete(id);
        return "redirect:/index";
    }
    //Passenger Contoller______________
    
   @GetMapping("/passengerform")
    public String viewHomePage1(Model model) {
        List<Passenger> listpass = service.listAll();
        model.addAttribute("listpass", listpass);
        System.out.print("Get /");
        return "Passengerform";
    }
 
    @GetMapping("/news")
    public String add(Model model) {
        model.addAttribute("passenger", new Passenger());
        return "NewPassengerform";
    }
 
    @RequestMapping(value = "/saves", method = RequestMethod.POST)
    public String savePassenger(@ModelAttribute("passenger") Passenger passenger) {
        service.save(passenger);
        return "redirect:/passengerform";
    }
 
    @RequestMapping("/edits/{pid}")
    public ModelAndView showEditPassengerPage(@PathVariable(name = "pid") int id) {
        ModelAndView mav1 = new ModelAndView("NewPassengerform");
        Passenger std1 = service.get(id);
        mav1.addObject("passenger", std1);
        return mav1;
        
    }
    @RequestMapping("/deletes/{pid}")
    public String deletePassenger(@PathVariable(name = "pid") int id) {
        service.delete(id);
        return "redirect:/passengerform";
    }
    
    @RequestMapping("/editss/{Ticket_no}")
    public ModelAndView showEditTrainPages(@PathVariable(name = "Ticket_no") int id) {
        ModelAndView mav1 = new ModelAndView("MainTicket");
        TrainTicket std = servic.get(id);
        mav1.addObject("traint", std);
        return mav1;
    
    }
    
    //__________Ticket
    
    @GetMapping("/newss")
    public String addis(Model modelss) {
    	
        modelss.addAttribute("traint", new TrainTicket());
       
        return "TicketPassenger";
    }
    
    @RequestMapping("/generate")
    public  ModelAndView showform(@ModelAttribute("ticket") Ticket ticket ,@ModelAttribute("train") Train train)
    {
    	 ModelAndView mav2 = new ModelAndView("FinalTicket");
    	 
    	 
    	 System.out.println(train);
    	 System.out.println(ticket);
    	
    	 return mav2;
    }
    
    @GetMapping("/newsw")
    public String add1(Model modela) {
        modela.addAttribute("passenger", new Passenger());
        return "TicketPassenger";
    }
    
    @RequestMapping(value = "/savess", method = RequestMethod.POST)
    public String savePassenger1(@ModelAttribute("passenger") Passenger passenger) {
        service.save(passenger);
        return "redirect:/GenerateTicket";
    }
    
    @RequestMapping("/edita/{Train_no}")
    public ModelAndView showEditTrainPage2(Model modela , @PathVariable(name = "Train_no") int id) {
        ModelAndView mav3 = new ModelAndView("TicketPassenger");
         modela.addAttribute("traint", new TrainTicket());
        Train std = services.get(id);
        mav3.addObject("train", std);
        
        return mav3;
    
    
    
    }
    
    
    //TrainTicket____________________________________
    
    @GetMapping("/index2")
    public String viewHomePageTicket(Model modele) {
        List<TrainTicket> listtrain = servic.listAll();
        modele.addAttribute("listtrain", listtrain);
        System.out.print("Get /");
        return "FinalTicket"; //write some form
    }
    
    @RequestMapping(value = "/save1", method = RequestMethod.POST)
    public String saveTrain2(@ModelAttribute("traint") TrainTicket traint) {
    	
        servic.save(traint);
        return "redirect:/index2";
    }
    //delete
    @RequestMapping("/deletess/{Ticket_no}")
    public String deletetrain1(@PathVariable(name = "Ticket_no") int id) {
        servic.delete(id);
        return "redirect:/index2";
    }
    
   
}



