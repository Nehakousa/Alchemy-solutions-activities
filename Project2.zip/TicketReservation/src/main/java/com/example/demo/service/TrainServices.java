package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.demo.domain.Train;

import com.example.demo.repository.TrainRepository;

@Service
public class TrainServices {
	@Autowired
    private TrainRepository repo;
public List<Train> listAll() {
        return repo.findAll();
    }
    
    public void save(Train train) {
        repo.save(train);
    }
    
    public Train get(int Train_no) {
        return repo.findById(Train_no).get();
    }
    
    public void delete(int  Train_no) {
    	 repo.deleteById(Train_no);
    	
    }

}
