package com.example.demo.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;

import com.example.demo.model.Train;
import com.example.demo.repository.TrainRepoository;


public class TrainService {
	
	@Autowired
    private TrainRepoository repo;
public List<Train> listAll() {
        return repo.findAll();
    }

public void save(Train train) {
    repo.save(train);
}

public Optional<Train> getTrainByNumber(int trainNumber) {
	return repo.findById(trainNumber);
}
public void delete(int  Train_no) {
  	 repo.deleteById(Train_no);
  	
  }


}
