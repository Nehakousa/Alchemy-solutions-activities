
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.Date;
import java.util.Scanner;


public class TicketApplication{

	public static void main(String[] args) throws ClassNotFoundException,SQLException, IOException {
		// TODO Auto-generated method stub
		int trainNo;
		//int trainno=0;
		LocalDate travelDate;
		int passengerCount=0;
		String passengerName=" ";
		String trainName=" ",source=" ",destination=" ";
		int ticketPrice=0; 
		int age=0;
		char gender=' ';
		double totalPrice=0;
		boolean trainExist=false;
		LocalDate today=LocalDate.now();
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the Train Number");
		trainNo=sc.nextInt();
		String qry="select * from trains where Train_no"+"="+trainNo;
		try {
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/train_booking","root", "admin");
		Statement stmt=con.createStatement();
		ResultSet rs=stmt.executeQuery(qry);
		rs.next();
		trainName=rs.getString("train_name");
		source=rs.getString("source");
		destination=rs.getString("destination");
		ticketPrice=rs.getInt("ticket_price");
		if(rs.getInt("train_no")==trainNo)
			trainExist=true;
		}
		catch(SQLException e) {
			System.out.println("Enter Details Correctly");
		}
		catch(ClassNotFoundException e1) {
			System.out.println("Please Check the Details properly");
		}
		Train train=new Train(trainNo,trainName,source,destination,ticketPrice);
		if(trainExist) {
			System.out.println("Enter Travel Date(yyyy-mm-dd)");
			travelDate=LocalDate.parse(sc.next());
		//System.out.println("Train No:"+train.getTrainNo()+"Train name:"+train.getTrainName()+"Source"+train.getSource()+"Destination:"+train.getDestination()+"TicketPrice:"+train.getTicketPrice());
		Ticket t=new Ticket(travelDate,train);
		if(travelDate.compareTo(today)>0) {
			System.out.println("Enter Number of Passengers");
			passengerCount=sc.nextInt();
			while(passengerCount!=0) {
				Scanner scr=new Scanner(System.in);
				System.out.println("Enter Passenger Name");
				passengerName=scr.next();
				System.out.println("Enter Age");
				age=scr.nextInt();
				System.out.println("Enter Gender(M/F)");
				gender=scr.next().charAt(0);
				Passenger p=new Passenger(passengerName,age,gender);
				t.addPassenger(passengerName,age,gender);
				passengerCount--;
			}
			System.out.println("Ticket Booked with PNR:"+t.generatePNR());
			t.generateTicket();
			t.writeTicket();
		}
		else {
			System.out.println("Travel Date is before Current Date");
		}
		}
			
	
		else {
			System.out.println("Train with given number does not exist");
		}
}
}