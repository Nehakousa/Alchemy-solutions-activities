package com.example.demo.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Trains")
public class Train {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	public int Train_no;
	
	@Column(name="Train_name")
	public String Train_name;
	
	@Column(name="source" )
	public String source;
	
	@Column(name="destination")
	public String Destination;
	
	@Column(name="price")
	public double price;
	
	public Train()
	{
		
	}
	public Train( String train_name, String source, String destination, double price) {
		super();
		
		Train_name = train_name;
		this.source = source;
		Destination = destination;
		this.price = price;
	}
	public int getTrain_no() {
		return Train_no;
	}
	public void setTrain_no(int train_no) {
		Train_no = train_no;
	}
	public String getTrain_name() {
		return Train_name;
	}
	public void setTrain_name(String train_name) {
		Train_name = train_name;
	}
	public String getSource() {
		return source;
	}
	public void setSource(String source) {
		this.source = source;
	}
	public String getDestination() {
		return Destination;
	}
	public void setDestination(String destination) {
		Destination = destination;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	@Override
	public String toString() {
		return "Train [Train_no=" + Train_no + ", Train_name=" + Train_name + ", source=" + source + ", Destination="
				+ Destination + ", price=" + price + "]";
	}
	
	
}
