package com.example.demo.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name="Ticket_Details")
public class TrainTicket {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	public int Ticket_no;
	
	@Column(name="Train_name")
	public String Train_name;
	
	@Column(name="source" )
	public String source;
	
	@Column(name="destination")
	public String Destination;
	
	@Column(name="price")
	public double price;
	
	@Column(name="pnr" )
	private String pnr;
	
	@Column(name="Travel_date" )
	private String travel_date;
	
	@Column(name="no_of_pass")
	private int no_of_pass;
	
	@Column(name="name")
	private  String passenger_name;
	
	@Column(name="gender")
	private String gender;
	
	@Column(name="age")
	private int age;
	
	@Column(name="total_fare")
	private double total_fare;
	
	public TrainTicket()
	{
		
	}
	
	public TrainTicket(int ticket_no, String train_name, String source, String destination, String pnr , double price,
			String travel_date, int no_of_pass, String passenger_name, String gender, int age, double total_fare) {
		super();
		Ticket_no = ticket_no;
		Train_name = train_name;
		this.source = source;
		Destination = destination;
		this.pnr=pnr;
		this.price = price;
		this.travel_date = travel_date;
		this.no_of_pass = no_of_pass;
		this.passenger_name = passenger_name;
		this.gender = gender;
		this.age = age;
		this.total_fare = total_fare;
	}

       
	public String getPnr() {
		
		
		return pnr;
	}

	public void setPnr(String pnr) {
		this.pnr = pnr;
	}


	
	
	public int getTicket_no() {
		return Ticket_no;
	}



	public void setTicket_no(int ticket_no) {
		Ticket_no = ticket_no;
	}



	public String getTrain_name() {
		return Train_name;
	}



	public void setTrain_name(String train_name) {
		Train_name = train_name;
	}



	public String getSource() {
		return source;
	}



	public void setSource(String source) {
		this.source = source;
	}



	public String getDestination() {
		return Destination;
	}



	public void setDestination(String destination) {
		Destination = destination;
	}



	public double getPrice() {
		return price;
	}



	public void setPrice(double price) {
		this.price = price;
	}



	public String getTravel_date() {
		return travel_date;
	}



	public void setTravel_date(String travel_date) {
		this.travel_date = travel_date;
	}



	public int getNo_of_pass() {
		return no_of_pass;
	}



	public void setNo_of_pass(int no_of_pass) {
		this.no_of_pass = no_of_pass;
	}



	public String getPassenger_name() {
		return passenger_name;
	}



	public void setPassenger_name(String passenger_name) {
		this.passenger_name = passenger_name;
	}



	public String getGender() {
		return gender;
	}



	public void setGender(String gender) {
		this.gender = gender;
	}



	public int getAge() {
		return age;
	}



	public void setAge(int age) {
		this.age = age;
	}

   public double getTotal_fare() {
		int n=getNo_of_pass();
		double total_fare=0;
		double fare=getPrice();
		for(int i=0;i<n;i++)
		{
			total_fare+=fare;
		}
		return total_fare;
	}



	public void setTotal_fare(double total_fare) {
		this.total_fare = total_fare;
	}



	



	@Override
	public String toString() {
		return "TrainTicket [Ticket_no=" + Ticket_no + ", Train_name=" + Train_name + ", source=" + source
				+ ", Destination=" + Destination + ", price=" + price + ", travel_date=" + travel_date + ", no_of_pass="
				+ no_of_pass + ", passenger_name=" + passenger_name + ", gender=" + gender + ", age=" + age
				+ ", total_fare=" + total_fare + "]";
	}

	
	

}
