package com.example.demo.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="passenger")
public class Passenger {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int pid;
	
	@Column(name="name")
	private  String passenger_name;
	
	@Column(name="gender")
	private String gender;
	
	@Column(name="age")
	private int age;

	
	public Passenger()
	{
		
	}


	public Passenger(String passenger_name, String gender, int age) {
		super();
		this.passenger_name = passenger_name;
		this.gender = gender;
		this.age = age;
	}


	public int getPid() {
		return pid;
	}


	public void setPid(int pid) {
		this.pid = pid;
	}


	public String getPassenger_name() {
		return passenger_name;
	}


	public void setPassenger_name(String passenger_name) {
		this.passenger_name = passenger_name;
	}


	public String getGender() {
		return gender;
	}


	public void setGender(String gender) {
		this.gender = gender;
	}


	public int getAge() {
		return age;
	}


	public void setAge(int age) {
		this.age = age;
	}


	@Override
	public String toString() {
		return "Passenger [pid=" + pid + ", passenger_name=" + passenger_name + ", gender=" + gender + ", age=" + age
				+ "]";
	}
	
}